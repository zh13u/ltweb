import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import ApiService from "./ApiService";
import { isAdminHost } from "../utils/hostRouting";


export const ProtectedRoute = ({element: Component}) => {
    const location = useLocation();

    return ApiService.isAuthenticated() ? (
        Component
    ):(
        <Navigate to="/login" replace state={{from: location}}/>
    );
};


export const AdminRoute = ({element: Component}) => {
    const location = useLocation();

    if (!isAdminHost() && window.location.hostname !== "localhost") {
        window.location.assign(`${window.location.protocol}//admin.hautc.waf${location.pathname}${window.location.search}`);
        return null;
    }

    return ApiService.isAdmin() ? (
        Component
    ):(
        <Navigate to="/login" replace state={{from: location}}/>
    );
};

export const UserRoute = ({element: Component}) => {
    const location = useLocation();

    // Block admin from accessing user pages
    if (ApiService.isAdmin()) {
        if (window.location.hostname !== "localhost" && !isAdminHost()) {
            window.location.assign(`${window.location.protocol}//admin.hautc.waf/admin`);
            return null;
        }
        return <Navigate to="/admin" replace state={{from: location}}/>;
    }

    return ApiService.isAuthenticated() ? (
        Component
    ):(
        <Navigate to="/login" replace state={{from: location}}/>
    );
};
