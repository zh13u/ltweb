const getCurrentOrigin = () => window.location.origin;

const buildOrigin = (hostname) => `${window.location.protocol}//${hostname}`;

export const isAdminHost = () => window.location.hostname === "admin.hautc.waf";

export const isClientHost = () => window.location.hostname === "app.hautc.waf";

export const getAdminOrigin = () => {
  if (isAdminHost()) {
    return getCurrentOrigin();
  }
  return buildOrigin("admin.hautc.waf");
};

export const getClientOrigin = () => {
  if (isClientHost()) {
    return getCurrentOrigin();
  }
  return buildOrigin("app.hautc.waf");
};

export const redirectToAdminApp = (path = "/admin") => {
  window.location.assign(`${getAdminOrigin()}${path}`);
};

export const redirectToClientApp = (path = "/") => {
  window.location.assign(`${getClientOrigin()}${path}`);
};
