package org.example.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
@Slf4j
public class LocalFileStorageService {

    @Value("${app.upload.dir}")
    private String uploadDir;

    @Value("${app.upload.public-base-url}")
    private String publicBaseUrl;

    public String saveImage(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new RuntimeException("Image file is required");
        }

        try {
            Path productUploadDir = Paths.get(uploadDir, "products");
            Files.createDirectories(productUploadDir);

            String originalFilename = StringUtils.cleanPath(file.getOriginalFilename() == null ? "" : file.getOriginalFilename());
            String extension = getFileExtension(originalFilename);
            String fileName = UUID.randomUUID() + extension;

            Path targetFile = productUploadDir.resolve(fileName);
            Files.copy(file.getInputStream(), targetFile, StandardCopyOption.REPLACE_EXISTING);

            return normalizePublicBaseUrl(publicBaseUrl) + "/products/" + fileName;
        } catch (IOException e) {
            log.error("Error while saving image locally: {}", e.getMessage(), e);
            throw new RuntimeException("Error while saving image locally");
        }
    }

    private String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex == -1 || dotIndex == fileName.length() - 1) {
            return ".jpg";
        }
        return fileName.substring(dotIndex);
    }

    private String normalizePublicBaseUrl(String baseUrl) {
        if (!StringUtils.hasText(baseUrl)) {
            return "/uploads";
        }

        String trimmedBaseUrl = baseUrl.trim();
        try {
            URI uri = new URI(trimmedBaseUrl);
            if (StringUtils.hasText(uri.getScheme())) {
                String path = uri.getPath();
                return StringUtils.hasText(path) ? trimTrailingSlash(path) : "/uploads";
            }
        } catch (URISyntaxException e) {
            log.warn("Invalid app.upload.public-base-url '{}', falling back to path handling", trimmedBaseUrl);
        }

        if (!trimmedBaseUrl.startsWith("/")) {
            trimmedBaseUrl = "/" + trimmedBaseUrl;
        }
        return trimTrailingSlash(trimmedBaseUrl);
    }

    private String trimTrailingSlash(String value) {
        return value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }
}
